#include <stdio.h>
#include <gst/gst.h>

int main(int argc, char *argv[]) {
  GstElement *pipeline, *filesrc, *decodebin, *audioconvert, *wavescope, *videoconvert, *autovideosink;
  GstBus *bus;
  GstMessage *msg;

  /* Initialize GStreamer */
  gst_init(&argc, &argv);

  /* Create elements */
  pipeline = gst_pipeline_new("audio-visualization");
  filesrc = gst_element_factory_make("filesrc", "file-source");
  decodebin = gst_element_factory_make("decodebin", "decoder");
  audioconvert = gst_element_factory_make("audioconvert", "audio-converter");
  wavescope = gst_element_factory_make("wavescope", "wave-scope");
  videoconvert = gst_element_factory_make("videoconvert", "video-converter");
  autovideosink = gst_element_factory_make("autovideosink", "video-sink");

  /* Set file source location */
  g_object_set(G_OBJECT(filesrc), "location", "https://www.jiosaavn.com/featured/tu-jhoothi-main-makkaar/ZzSHMT7anu4V3Xpvr9dnYw__", NULL);

  /* Add elements to pipeline */
  gst_bin_add_many(GST_BIN(pipeline), filesrc, decodebin, audioconvert, wavescope, videoconvert, autovideosink, NULL);

  /* Link elements */
  gst_element_link_many(filesrc, decodebin, audioconvert, wavescope, videoconvert, autovideosink, NULL);

  /* Set wavescope parameters */
  g_object_set(G_OBJECT(wavescope), "shader", "none", NULL);
  g_object_set(G_OBJECT(wavescope), "style", "lines", NULL);

  /* Start playing */
  gst_element_set_state(pipeline, GST_STATE_PLAYING);

  /* Wait until error or EOS */
  bus = gst_element_get_bus(pipeline);
  msg = gst_bus_timed_pop_filtered(bus, GST_CLOCK_TIME_NONE, GST_MESSAGE_ERROR | GST_MESSAGE_EOS);

  /* Free resources */
  if (msg != NULL) {
    gst_message_unref(msg);
  }
  gst_object_unref(bus);
  gst_element_set_state(pipeline, GST_STATE_NULL);
  gst_object_unref(pipeline);
  return 0;
}

/*NOTE :- Here is have given the path of audio which may be any audio file, 
please keep that in mind before compiling/running the above code
wobot/assig2/audio/audio.mp3 or
https://www.jiosaavn.com/featured/tu-jhoothi-main-makkaar/ZzSHMT7anu4V3Xpvr9dnYw__ */