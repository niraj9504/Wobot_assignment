
#include<iostream>
#include"function.h"
using namespace std;
void print_hello(){
cout<<"hello wobot"<<endl;
}

