I have made MakeFile, so directly we can compile the file by
running the command :-  make 
It will make a executable file, after that we can run that
by running the command :- ./hello    (executable file name)
for clearing the executable file created:- make clean


Alternatively,

for compiling :- 
1.  g++  function1.cpp function2.cpp main.cpp -o hello
2. for running ./hello