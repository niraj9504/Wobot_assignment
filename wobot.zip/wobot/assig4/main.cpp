#include<iostream>
#include"function.h"
using namespace std;
int main(){
print_hello();
cout<<endl;
cout<<factorial(5);
cout<<endl;
}
