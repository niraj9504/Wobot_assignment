#include <gst/gst.h>

/* Structure to hold custom source element data */
typedef struct _CustomSrcData {
  GstElement *src;
  GstPad *src_pad;
  GstBuffer *buf;
  guint64 offset;
  guint64 size;
} CustomSrcData;

/* Callback function for the custom source element */
static gboolean cb_custom_src_create(GstPushSrc *src, GstBuffer **buf) {
  CustomSrcData *data = (CustomSrcData *)src;
  if (data->buf) {
    *buf = data->buf;
    data->buf = NULL;
    return GST_FLOW_OK;
  } else {
    return GST_FLOW_ERROR;
  }
}

/* Callback function for the custom source element */
static gboolean cb_custom_src_query(GstPad *pad, GstObject *obj, GstQuery *query) {
  CustomSrcData *data = (CustomSrcData *)obj;
  GstFormat format;
  gint64 value;
  gboolean res;

  switch (GST_QUERY_TYPE(query)) {
    case GST_QUERY_POSITION:
      gst_query_parse_position(query, &format, &value);
      if (format == GST_FORMAT_DEFAULT) {
        value = data->offset + GST_BUFFER_OFFSET(data->buf);
        gst_query_set_position(query, GST_FORMAT_DEFAULT, value);
        res = TRUE;
      } else {
        res = FALSE;
      }
      break;
    case GST_QUERY_TOTAL:
      gst_query_parse_duration(query, &format, &value);
      if (format == GST_FORMAT_BYTES) {
        value = data->size;
        gst_query_set_duration(query, GST_FORMAT_BYTES, value);
        res = TRUE;
      } else {
        res = FALSE;
      }
      break;
    default:
      res = GST_PAD_CLASS(parent_class)->query(pad, obj, query);
      break;
  }

  return res;
}

int main(int argc, char *argv[]) {
  GstElement *pipeline, *customsrc, *tee, *queue, *blur, *videoconvert, *autovideosink;
  GstPad *srcpad, *queuepad, *blurpad, *sinkpad;
  GstBus *bus;
  GstMessage *msg;
  CustomSrcData *srcdata;

  /* Initialize GStreamer */
  gst_init(&argc, &argv);

  /* Create pipeline */
  pipeline = gst_pipeline_new("custom-source-tee-blur-output");

  /* Create elements */
  customsrc = gst_element_factory_make("pushsrc", "custom-source");
  tee = gst_element_factory_make("tee", "splitter");
  queue = gst_element_factory_make("queue", "queue");
  blur = gst_element_factory_make("videobalance", "blur");
  videoconvert = gst_element_factory_make("videoconvert", "converter");
  autovideosink = gst_element_factory_make("autovideosink", "video-sink");

  /* Set up custom source element */
  srcdata = g_new0(CustomSrcData, 1);
  srcdata->src = customsrc;
  srcdata->src_pad = gst_element_get_static_pad(customsrc, "src");
  gst_pad_set_activate_function(srcdata->src_pad, cb_custom_src_create);
  gst_pad_set_query_function(srcdata->src_pad, cb_custom_src_query);
  gst_element_add_pad(pipeline, gst_ghost_pad_new("src", srcdata->src_pad));

  /* Add elements to pipeline */
  gst_bin_add_many(GST_BIN(pipeline), tee, queue, blur, videoconvert, autovideosink, NULL);


  /* Link the elements together */
  if (!gst_element_link_many(queue, blur, videoconvert, autovideosink, NULL)) {
    g_error("Failed to link elements");
    return -1;
  }

  /* Link the tee to the queue and blur */
  srcpad = gst_element_get_static_pad(tee, "src");
  queuepad = gst_element_get_static_pad(queue, "sink");
  blurpad = gst_element_get_static_pad(blur, "sink");
  if (gst_pad_link(srcpad, queuepad) != GST_PAD_LINK_OK ||
      gst_pad_link(srcpad, blurpad) != GST_PAD_LINK_OK) {
    g_error("Failed to link tee to queue and blur");
    return -1;
  }
  gst_object_unref(srcpad);
  gst_object_unref(queuepad);
  gst_object_unref(blurpad);

  /* Start the pipeline */
  gst_element_set_state(pipeline, GST_STATE_PLAYING);

  /* Wait for pipeline to finish or error */
  bus = gst_element_get_bus(pipeline);
  msg = gst_bus_timed_pop_filtered(bus, GST_CLOCK_TIME_NONE, GST_MESSAGE_ERROR | GST_MESSAGE_EOS);
  gst_message_unref(msg);

  /* Stop the pipeline */
  gst_element_set_state(pipeline, GST_STATE_NULL);

  /* Free resources */
  gst_object_unref(bus);
  gst_object_unref(srcdata->src_pad);
  gst_object_unref(srcdata->src);
  gst_object_unref(GST_OBJECT(pipeline));
  g_free(srcdata);

  return 0;
}
