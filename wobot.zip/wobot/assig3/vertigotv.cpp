#include <gst/gst.h>

/* Structure to hold custom source element data */
typedef struct _CustomSrcData {
  GstElement *src;
  GstPad *src_pad;
  GstBuffer *buf;
  guint64 offset;
  guint64 size;
} CustomSrcData;

/* Callback function for the custom source element */
static gboolean cb_custom_src_create(GstPushSrc *src, GstBuffer **buf) {
  CustomSrcData *data = (CustomSrcData *)src;
  if (data->buf) {
    *buf = data->buf;
    data->buf = NULL;
    return GST_FLOW_OK;
  } else {
    return GST_FLOW_ERROR;
  }
}

/* Callback function for the custom source element */
static gboolean cb_custom_src_query(GstPad *pad, GstObject *obj, GstQuery *query) {
  CustomSrcData *data = (CustomSrcData *)obj;
  GstFormat format;
  gint64 value;
  gboolean res;

  switch (GST_QUERY_TYPE(query)) {
    case GST_QUERY_POSITION:
      gst_query_parse_position(query, &format, &value);
      if (format == GST_FORMAT_DEFAULT) {
        value = data->offset + GST_BUFFER_OFFSET(data->buf);
        gst_query_set_position(query, GST_FORMAT_DEFAULT, value);
        res = TRUE;
      } else {
        res = FALSE;
      }
      break;
    case GST_QUERY_TOTAL:
      gst_query_parse_duration(query, &format, &value);
      if (format == GST_FORMAT_BYTES) {
        value = data->size;
        gst_query_set_duration(query, GST_FORMAT_BYTES, value);
        res = TRUE;
      } else {
        res = FALSE;
      }
      break;
    default:
      res = GST_PAD_CLASS(parent_class)->query(pad, obj, query);
      break;
  }

  return res;
}

int main(int argc, char *argv[]) {
  GstElement *pipeline, *customsrc, *videoconvert, *autovideosink;
  GstPad *srcpad, *sinkpad;
  GstBus *bus;
  GstMessage *msg;
  CustomSrcData *srcdata;

  /* Initialize GStreamer */
  gst_init(&argc, &argv);

  /* Create pipeline */
  pipeline = gst_pipeline_new("custom-source-output");

  /* Create elements */
  customsrc = gst_element_factory_make("pushsrc", "custom-source");
  videoconvert = gst_element_factory_make("videoconvert", "converter");
  autovideosink = gst_element_factory_make("autovideosink", "video-sink");

  /* Set up custom source element */
  srcdata = g_new0(CustomSrcData, 1);
  srcdata->src = customsrc;
  srcdata->src_pad = gst_element_get_static_pad(customsrc, "src");
  gst_pad_set_activate_function(srcdata->src_pad, cb_custom_src_create);
  gst_pad_set_query_function(srcdata->src_pad, cb_custom_src_query);
  gst_element_add_pad(pipeline, gst_ghost_pad_new("src", srcdata->src_pad));

  /* Add elements to pipeline */
  gst_bin_add_many(GST_BIN(pipeline), videoconvert, autovideosink, NULL);

  /* Link the elements together */
  if (!gst_element_link_many(customsrc, videoconvert, autovideosink, NULL)) {
    g_printerr("Failed to link elements\n");
    return -1;
  }


  /* Set the URI for the custom source element */
  g_object_set(customsrc, "uri", "vertigotv://", NULL);

  /* Start playing */
  gst_element_set_state(pipeline, GST_STATE_PLAYING);

  /* Wait until error or EOS */
  bus = gst_element_get_bus(pipeline);
  msg = gst_bus_timed_pop_filtered(bus, GST_CLOCK_TIME_NONE, (GstMessageType)(GST_MESSAGE_ERROR | GST_MESSAGE_EOS));

  /* Free resources */
  if (msg != NULL) {
    gst_message_unref(msg);
  }
  gst_object_unref(bus);
  gst_element_set_state(pipeline, GST_STATE_NULL);
  gst_object_unref(pipeline);
  g_free(srcdata);

  return 0;
}
