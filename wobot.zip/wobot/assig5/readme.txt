To implement a plugin that performs a blur operation using OpenCV's inbuilt blur functionality,
you will need to follow these basic steps:-

1. Define the plugin's details: In the plugin's code, 
we will define the plugin's details such as the name, 
description, version, author, and license.

2. Define the plugin's element: Define the element that 
will perform the blur operation. The element should have
an input pad and an output pad.

3. Implement the element's processing function: Implement 
the element's processing function that will perform the 
blur operation using OpenCV's inbuilt blur functionality. 
The processing function should take an input buffer, apply 
the blur operation, and output the result buffer.

4. Build and install the plugin: Build the plugin using 
a build system such as Autotools or CMake, and install it 
to the system's plugin directory.


I am facing problems in downloading the GStreamer on my macbook,
so unable to varify my code for the 5th assignment. Also I have 
think the ways and mentioned here that how can we proceed to
solve the 5th one.
